<div class="p-3 border border-light text-center">
    Sorry! No data to display
</div>